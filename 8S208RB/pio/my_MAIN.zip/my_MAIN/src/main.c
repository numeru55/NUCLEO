/*

from
~/.platformio/platforms/ststm8/examples/spl-uart-simple-printf

*/

#include "stm8s.h"
#include "stm8s_it.h" /* SDCC patch: required by SDCC for interrupts */
#include "stdio.h"

#define PUTCHAR_PROTOTYPE int putchar(int c)
#define GETCHAR_PROTOTYPE int getchar(void)

void my_setup();
void my_delay(uint8_t c);

void main(void)
{

  my_setup();
  my_delay(3000);

  /* Output a message on Hyperterminal using printf function */
  printf("UART1 Example :retarget the C library printf()/getchar() functions to the UART\n");

  // print test
  uint8_t c8 = 0;
  c8 = c8 + 1;
  printf("Count %d\n", c8);

  enableInterrupts();

  while (1)
  {
    // char ans = getchar();
    // printf("%c", ans);
  }
}

void my_setup()
{
  /* High speed internal clock prescaler: */
  CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);

  UART1_DeInit();
  UART1_Init(
      (uint32_t)9600,
      UART1_WORDLENGTH_8D,
      UART1_STOPBITS_1,
      UART1_PARITY_NO,
      UART1_SYNCMODE_CLOCK_DISABLE,
      UART1_MODE_TXRX_ENABLE);

  TIM1_DeInit();
  TIM1_TimeBaseInit(  // refer packages - framework ... - Libraries - STM8... - src - stm8_tim1.c
    1599, // prescaler to TIM1->PSCRH, TIM1->PSCRL
    TIM1_COUNTERMODE_UP, 
    5000,  // period to TIM1->ARRH, TIM1->ARRL
    0); // TIM1_RepetitionCounter to TIM1->RCR
  TIM1_ITConfig(TIM1_IT_UPDATE, ENABLE);
  TIM1_Cmd(ENABLE); // set TIM1->CR1 of CEN 

  GPIO_Init(GPIOC, GPIO_PIN_5, GPIO_MODE_OUT_PP_HIGH_FAST);
}

void my_delay(uint8_t c) // wait about c [sec]
{
  for (uint8_t c0 = 0; c0 < c; c0++)
  {
    // simple wait ~1000ms @ 16MHz
    for (uint32_t i = 0; i < 1600L; i++)
      __asm__("nop");
  }
}

/**
 * @brief Retargets the C library printf function to the UART.
 * @param c Character to send
 * @retval char Character sent
 */
PUTCHAR_PROTOTYPE
{
  /* Write a character to the UART1 */
  UART1_SendData8(c);
  /* Loop until the end of transmission */
  while (UART1_GetFlagStatus(UART1_FLAG_TXE) == RESET)
    ;

  return (c);
}

/**
 * @brief Retargets the C library scanf function to the USART.
 * @param None
 * @retval char Character to Read
 */
GETCHAR_PROTOTYPE
{
#ifdef _COSMIC_
  char c = 0;
#else
  int c = 0;
#endif
  /* Loop until the Read data register flag is SET */
  while (UART1_GetFlagStatus(UART1_FLAG_TXE) == RESET)
    ;
  c = UART1_ReceiveData8();
  return (c);
}

#ifdef USE_FULL_ASSERT

/**
 * @brief  Reports the name of the source file and the source line number
 *   where the assert_param error has occurred.
 * @param file: pointer to the source file name
 * @param line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  (void)file;
  (void)line;
  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
 * @}
 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
